import { Project, Feature, Testimonial, PricingPlan } from "./types";

export const FEATURES_DATA: Feature[] = [
  {
    id: "feat-1",
    title: "Neural Engine Orchestration",
    description: "Orchestrate multi-agent LLM systems with autonomous memory caching and self-optimizing feedback loops.",
    iconName: "BrainCircuit",
    gradient: "from-purple-500 via-fuchsia-500 to-pink-500",
    badge: "AI Native",
    interactiveType: "stats"
  },
  {
    id: "feat-2",
    title: "Real-time Consensus Ledger",
    description: "Execute microsecond financial settlements with absolute multi-region redundancy and verified cryptography.",
    iconName: "ShieldCheck",
    gradient: "from-cyan-500 via-teal-500 to-emerald-500",
    badge: "Enterprise",
    interactiveType: "chart"
  },
  {
    id: "feat-3",
    title: "Edge Delivery Gateway",
    description: "Run dynamic WebAssembly routers on a global network with sub-5ms routing and adaptive cold-start bypass.",
    iconName: "Zap",
    gradient: "from-orange-500 via-amber-500 to-yellow-500",
    interactiveType: "code"
  },
  {
    id: "feat-4",
    title: "Cognitive Collaboration",
    description: "Synchronize visual team thoughts instantly using local-first SQLite nodes and multi-user CRDT conflict resolution.",
    iconName: "Users",
    gradient: "from-blue-500 via-indigo-500 to-violet-500",
    interactiveType: "toggle"
  },
  {
    id: "feat-5",
    title: "Automated Threat Defense",
    description: "Predict zero-day anomalies and enforce real-time network quarantine zones using lightweight local neural nets.",
    iconName: "Fingerprint",
    gradient: "from-rose-500 via-pink-500 to-purple-500",
    badge: "New"
  },
  {
    id: "feat-6",
    title: "Global Mesh Network",
    description: "Connect multi-cloud nodes securely without VPC peering, utilizing wireguard tunnels and BGP pathing.",
    iconName: "Globe",
    gradient: "from-emerald-500 via-cyan-500 to-indigo-500"
  }
];

export const PROJECTS_DATA: Project[] = [
  {
    id: "proj-1",
    title: "Aether Intelligence",
    description: "Autonomous multi-agent task orchestrator with long-term semantic memory and self-debugging workspace environments.",
    category: "AI Platform",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=800&auto=format&fit=crop",
    tags: ["LLM Agents", "Vector DB", "React-Flow"],
    metrics: { label: "Task Efficiency", value: "+340%" },
    longDescription: "Aether is a visual dashboard that allows organizations to deploy agent swarms that run autonomous tasks. It integrates advanced semantic memory databases and offers sandbox execution zones where agents write, test, and run their own code solutions safely.",
    demoUrl: "https://aether.example.com",
    features: ["Visual Flow Builder", "Autonomous Refactoring", "Cognitive Memory Caching", "Docker Sandbox Execution"]
  },
  {
    id: "proj-2",
    title: "Apex Ledger",
    description: "Next-generation distributed ledger framework processing 100k+ transactions per second with sub-millisecond settlement.",
    category: "FinTech",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=800&auto=format&fit=crop",
    tags: ["Rust", "gRPC", "Distributed DB", "Raft"],
    metrics: { label: "Latency", value: "0.18ms" },
    longDescription: "Apex Ledger sets a new benchmark for corporate ledgers. Utilizing a custom Raft consensus mechanism built in Rust, it allows global banking APIs to transact and reconcile balances in real-time, eliminating standard batch processing and visual delay.",
    demoUrl: "https://apex.example.com",
    features: ["Raft Consensus Engine", "Encrypted Audit Trails", "gRPC Streaming APIs", "Hardware-Security-Module Friendly"]
  },
  {
    id: "proj-3",
    title: "Nexus Edge Router",
    description: "Ultra-low latency edge gateway optimized for running WebAssembly serverless workloads with auto-scaling instances.",
    category: "DevTools",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=800&auto=format&fit=crop",
    tags: ["WebAssembly", "Cloudflare", "TypeScript", "Deno"],
    metrics: { label: "Global Cold Start", value: "<1.2ms" },
    longDescription: "Nexus replaces traditional heavy container routing with lightweight WebAssembly isolates. Workloads are distributed dynamically to the nearest topological node, cutting routing latency down to the speed of physical light limits.",
    demoUrl: "https://nexus.example.com",
    features: ["WASM Sandboxing", "Dynamic Path Optimization", "Integrated Key-Value Store", "Instant CLI Deployment"]
  },
  {
    id: "proj-4",
    title: "Optima Workspace",
    description: "Collaborative cognitive whiteboard designed for distributed engineering teams, powered by real-time CRDT engines.",
    category: "SaaS Core",
    image: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?q=80&w=800&auto=format&fit=crop",
    tags: ["CRDT", "WebSockets", "Canvas API", "IndexedDB"],
    metrics: { label: "Sync Latency", value: "<15ms" },
    longDescription: "Optima is an offline-first collaborative planning board that handles hundreds of concurrent users smoothly. Changes are synced locally first and resolved on conflict using advanced commutative replicated data types.",
    demoUrl: "https://optima.example.com",
    features: ["Infinite Multi-Canvas", "Rich Text Synced Editor", "Audio-Chat Overlay", "Framer Motion Physics Engine"]
  },
  {
    id: "proj-5",
    title: "Helios Telemetry Server",
    description: "AI-powered server cluster observability tool providing real-time CPU thermal forecasting and dynamic throttle planning.",
    category: "AI Platform",
    image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=800&auto=format&fit=crop",
    tags: ["TimeSeries", "TensorFlow", "Kubernetes", "gRPC"],
    metrics: { label: "Server Cost Savings", value: "45%" },
    longDescription: "Helios prevents server thermal and performance throttling by anticipating high-traffic spikes through deep-learning temporal models. It automatically migrates processes and schedules server sleep states beforehand.",
    demoUrl: "https://helios.example.com",
    features: ["Thermal Signature Forecasting", "K8s Cluster Orchestrator", "Prometheus Scraping Layer", "Visual Anomaly Sandbox"]
  },
  {
    id: "proj-6",
    title: "Cipher Shield Protocol",
    description: "Zero-knowledge decentralized identity gateway enabling passwordless secure logins without holding user credentials.",
    category: "DevTools",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=800&auto=format&fit=crop",
    tags: ["Zero-Knowledge", "ECDSA", "Biometrics", "Passkeys"],
    metrics: { label: "Breach Vulnerability", value: "0.0%" },
    longDescription: "Cipher Shield enables modern web platforms to sign-in clients without ever asking, sending, or storing sensitive strings. It leverages hardware biometric security and elliptic curve cryptography to sign assertions securely.",
    demoUrl: "https://ciphershield.example.com",
    features: ["ZK-Snarks Proof System", "Direct Biometric Binding", "Anti-Phishing Token Headers", "Multi-Tenant Integration Kit"]
  }
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: "test-1",
    name: "Dr. Sarah Jenkins",
    role: "VP of Engineering",
    company: "Aetheric Labs",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=150&auto=format&fit=crop",
    content: "Deploying Aura's neural structures boosted our computational pipeline efficiency by over 300%. The bento-like insights and real-time ledger consensus saved our platform team countless debugging cycles. Exceptional visual aesthetics and flawless ergonomics.",
    rating: 5,
    date: "July 2026"
  },
  {
    id: "test-2",
    name: "Marcus Vance",
    role: "Principal Architect",
    company: "Solaria FinTech",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop",
    content: "The Edge router routing speeds are absolutely mind-blowing. We replaced our old Rust gateways with Aura's WebAssembly sandbox integration and immediately cut global latency down to 0.18ms. It is practically running at the speed of light.",
    rating: 5,
    date: "June 2026"
  },
  {
    id: "test-3",
    name: "Evelyn Sterling",
    role: "Lead Creative Technologist",
    company: "Neon Design Syndicate",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop",
    content: "From a pure UX/UI perspective, Aura is a masterpiece. The glassmorphic cards, fluid physics-based micro-interactions, and visual harmony in dark mode are exactly what elite developers dream of. This has significantly raised our standard.",
    rating: 5,
    date: "May 2026"
  }
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "plan-dev",
    name: "Developer",
    price: "$29",
    period: "month",
    description: "Perfect for builders, freelance engineers, and independent hackers wanting elite performance.",
    features: [
      "Access to standard WASM edge routing",
      "Up to 10 multi-agent active threads",
      "14 days of audit ledger history",
      "Standard vector memory indexing",
      "Discord community support"
    ],
    gradient: "from-slate-800 to-slate-900 border-slate-700/50",
    isPopular: false,
    buttonText: "Deploy Instantly"
  },
  {
    id: "plan-pro",
    name: "Professional",
    price: "$99",
    period: "month",
    description: "Designed for scaling startups and teams requiring dedicated high-speed infrastructure.",
    features: [
      "Dynamic path optimization (all regions)",
      "Unlimited multi-agent active threads",
      "Infinite audit ledger database logs",
      "Premium vector memory cache with sub-2ms lookup",
      "Priority 24/7 Slack and video support",
      "Self-healing Docker sandbox zones"
    ],
    gradient: "from-purple-950/40 via-indigo-950/40 to-slate-900 border-purple-500/30",
    isPopular: true,
    buttonText: "Scale with Pro"
  },
  {
    id: "plan-ent",
    name: "Enterprise",
    price: "$299",
    period: "month",
    description: "Custom dedicated isolation clusters with hardware-level security validation.",
    features: [
      "Dedicated multi-region network mesh",
      "Zero-knowledge customer authentication suite",
      "Hardware-Security-Module binding integrations",
      "Guaranteed 99.999% high-availability SLA",
      "Dedicated Technical Account Manager",
      "Custom on-premise cloud cluster mirroring"
    ],
    gradient: "from-slate-800 to-slate-900 border-slate-700/50",
    isPopular: false,
    buttonText: "Initiate Audit"
  }
];

import { useState } from "react";
import { ExternalLink, X, Info, Check, Sparkles, LayoutGrid, Award, Settings, Layers } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PROJECTS_DATA } from "../data";
import { Project } from "../types";

export default function Portfolio() {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const categories = ["All", "AI Platform", "FinTech", "SaaS Core", "DevTools"];

  const filteredProjects = selectedCategory === "All"
    ? PROJECTS_DATA
    : PROJECTS_DATA.filter(p => p.category === selectedCategory);

  return (
    <section id="showcase" className="py-24 relative bg-[#0B0F19] overflow-hidden">
      {/* Background soft glowing orb */}
      <div className="absolute top-1/4 right-0 w-[450px] h-[450px] bg-cyan-500/5 rounded-full blur-[130px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 left-0 w-[450px] h-[450px] bg-purple-500/5 rounded-full blur-[130px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 flex flex-col items-center gap-4">
          <span className="text-xs uppercase tracking-widest font-semibold font-mono bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-400">
            SHOWCASE GALLERY
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Engineered Masterpieces
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-neon-cyan to-electric-purple rounded-full my-1" />
          <p className="text-gray-400 text-sm sm:text-base leading-relaxed">
            Take an immersive tour through our deployment catalog. Hover to inspect real-world metrics, and click to explore deep architectural case studies.
          </p>
        </div>

        {/* Categories Filtering Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-4 mb-14" id="portfolio-categories">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`relative px-4 sm:px-6 py-2.5 rounded-full text-xs sm:text-sm font-semibold tracking-wide transition-all duration-300 overflow-hidden ${
                selectedCategory === category
                  ? "text-white shadow-[0_4px_15px_rgba(139,92,246,0.25)]"
                  : "text-gray-400 hover:text-white border border-white/5 hover:border-white/10 bg-white/5 hover:bg-white/10"
              }`}
            >
              {selectedCategory === category && (
                <motion.div
                  layoutId="activeCategoryBg"
                  className="absolute inset-0 bg-gradient-to-r from-electric-purple to-neon-cyan"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{category === "All" ? "All Projects" : category}</span>
            </button>
          ))}
        </div>

        {/* Projects Cards Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          id="portfolio-grid"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project: Project) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.92 }}
                transition={{ duration: 0.4 }}
                key={project.id}
                className="group relative flex flex-col justify-between bg-slate-900/40 rounded-2xl border border-white/5 overflow-hidden transition-all duration-500 hover:border-purple-500/20 hover:shadow-[0_15px_30px_rgba(139,92,246,0.15)]"
              >
                {/* Image and overlay section */}
                <div className="relative aspect-video w-full overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
                  />
                  {/* Subtle black gradient over image bottom */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-90" />

                  {/* Top Category Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-950/80 border border-white/10 text-cyan-300 backdrop-blur-sm shadow-md">
                      {project.category}
                    </span>
                  </div>

                  {/* Dynamic Metrics Glow Badge */}
                  <div className="absolute bottom-4 right-4 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-500/25 border border-purple-400/30 text-white backdrop-blur-md shadow-lg animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider">{project.metrics.label}:</span>
                    <span className="text-xs font-mono font-bold text-cyan-200">{project.metrics.value}</span>
                  </div>
                </div>

                {/* Body details */}
                <div className="p-6 flex flex-col gap-5 justify-between flex-grow">
                  <div className="flex flex-col gap-3">
                    <h3 className="font-display font-bold text-xl text-white group-hover:text-cyan-300 transition-colors duration-300">
                      {project.title}
                    </h3>
                    <p className="text-gray-400 text-xs sm:text-sm leading-relaxed line-clamp-2">
                      {project.description}
                    </p>
                  </div>

                  <div className="flex flex-col gap-4">
                    {/* Tags */}
                    <div className="flex flex-wrap gap-1.5">
                      {project.tags.map((tag) => (
                        <span key={tag} className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-slate-800 text-gray-300 border border-white/5">
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Interactive Click triggers Case Study Modal */}
                    <button
                      onClick={() => setSelectedProject(project)}
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold tracking-wide text-white bg-white/5 group-hover:bg-gradient-to-r group-hover:from-electric-purple group-hover:to-neon-cyan border border-white/5 group-hover:border-transparent transition-all duration-300 active:scale-[0.98]"
                    >
                      <Info className="w-4 h-4 text-purple-400 group-hover:text-[#0B0F19] transition-colors" />
                      <span>Explore Case Study</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Case Study High-Fidelity Details Modal Component */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Modal Glass Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
              className="absolute inset-0 bg-[#0B0F19]/80 backdrop-blur-md"
            />

            {/* Modal Body Panel */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="relative w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col z-10"
            >
              {/* Top border glowing highlight */}
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-electric-purple to-neon-cyan" />

              {/* Modal Banner Area */}
              <div className="relative aspect-[21/9] w-full overflow-hidden">
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  referrerPolicy="no-referrer"
                  className="object-cover w-full h-full"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

                {/* Close Button overlay */}
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-950 text-gray-400 hover:text-white border border-white/10 hover:scale-105 transition-all"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>

                {/* Banner title overlay */}
                <div className="absolute bottom-6 left-6 right-6 flex flex-wrap justify-between items-end gap-4">
                  <div>
                    <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/30 border border-purple-400/40 text-purple-200 backdrop-blur-md">
                      {selectedProject.category}
                    </span>
                    <h2 className="font-display font-bold text-2xl sm:text-3xl text-white mt-2">
                      {selectedProject.title}
                    </h2>
                  </div>
                  {/* Dynamic Metrics display */}
                  <div className="flex flex-col items-end">
                    <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">{selectedProject.metrics.label}</span>
                    <span className="text-xl sm:text-2xl font-mono font-bold text-cyan-400">{selectedProject.metrics.value}</span>
                  </div>
                </div>
              </div>

              {/* Modal Contents Scrollable area */}
              <div className="p-6 sm:p-8 overflow-y-auto flex-grow flex flex-col md:flex-row gap-8">
                {/* Left Side Column: Case Writeup & Technical list */}
                <div className="flex-grow md:w-3/5 flex flex-col gap-6">
                  <div>
                    <h4 className="text-xs uppercase tracking-widest font-semibold font-mono text-gray-400 flex items-center gap-2 mb-2">
                      <Layers className="w-4 h-4 text-purple-400" />
                      Executive Abstract
                    </h4>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      {selectedProject.longDescription || selectedProject.description}
                    </p>
                  </div>

                  <div>
                    <h4 className="text-xs uppercase tracking-widest font-semibold font-mono text-gray-400 flex items-center gap-2 mb-3">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      Architectural Features
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      {(selectedProject.features || [
                        "Sub-millisecond data sync loops",
                        "Fully decoupled micro-services layout",
                        "Zero-latency edge path compilers",
                        "Military-grade security quarantine modules"
                      ]).map((feat, index) => (
                        <div key={index} className="flex items-start gap-2.5 text-sm text-gray-300">
                          <div className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 mt-0.5 shrink-0">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Side Column: Meta, Stack & Action Buttons */}
                <div className="md:w-2/5 shrink-0 flex flex-col gap-6 border-t md:border-t-0 md:border-l border-white/10 pt-6 md:pt-0 md:pl-8">
                  {/* Technology Used */}
                  <div>
                    <h4 className="text-xs uppercase tracking-widest font-semibold font-mono text-gray-400 flex items-center gap-2 mb-3">
                      <Settings className="w-4 h-4 text-purple-400" />
                      Technology Stack
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.tags.map((tag) => (
                        <span key={tag} className="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold bg-slate-800 text-cyan-300 border border-white/5">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Core Quality Indicators */}
                  <div className="p-4 rounded-xl bg-slate-950/40 border border-white/5 flex flex-col gap-3">
                    <div className="flex items-center gap-3">
                      <Award className="w-5 h-5 text-amber-400" />
                      <span className="text-xs font-bold font-mono uppercase tracking-wider text-gray-300">AURA VALIDATED</span>
                    </div>
                    <p className="text-[11px] text-gray-400 leading-relaxed">
                      This build has passed high-concurrency stress auditing and is verified as production-grade.
                    </p>
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-col gap-3 mt-auto">
                    <a
                      href={selectedProject.demoUrl || "https://example.com"}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center justify-center gap-2.5 w-full py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-electric-purple to-neon-cyan shadow-lg shadow-purple-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
                    >
                      <span>Connect Deploy Node</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                    <button
                      onClick={() => setSelectedProject(null)}
                      className="w-full py-3.5 rounded-xl text-center text-sm font-semibold text-gray-400 hover:text-white border border-white/5 hover:border-white/15 bg-white/5 hover:bg-white/10 transition-all"
                    >
                      Return to Showcase
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

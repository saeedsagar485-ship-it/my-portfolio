import React, { useState } from "react";
import { Mail, Check, ArrowRight, Sparkles } from "lucide-react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes("@")) {
      setStatus("error");
      setTimeout(() => setStatus("idle"), 2500);
      return;
    }

    setStatus("submitting");

    // Simulate ledger commit/compilation
    setTimeout(() => {
      setStatus("success");
      setEmail("");
      // Save subscription state in localStorage
      try {
        localStorage.setItem("aura_subscribed_email", email);
      } catch (err) {
        console.error("Local Storage access blocked: ", err);
      }
    }, 1500);
  };

  return (
    <section id="newsletter" className="py-12 relative bg-[#0B0F19] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Call-to-Action Glass Block */}
        <div className="rounded-3xl glass-panel border border-white/10 p-8 sm:p-14 relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-10 shadow-2xl">
          {/* Top border glow highlighting */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />
          {/* Inner ambient glow spots */}
          <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-cyan-600/10 rounded-full blur-[80px]" />
          <div className="absolute -right-12 -top-12 w-64 h-64 bg-purple-600/10 rounded-full blur-[80px]" />

          {/* Left: Heading and description */}
          <div className="flex flex-col gap-4 text-center lg:text-left lg:max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-[10px] font-mono font-bold text-cyan-300 w-fit mx-auto lg:mx-0">
              <Sparkles className="w-3.5 h-3.5" />
              WEEKLY ENGINEERING LOGS
            </div>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-white tracking-tight leading-tight">
              Ready to Accelerate <br />
              Your Edge Deployments?
            </h2>
            <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
              Join our engineering dispatch newsletter. No sales spam—just deep-dives into WebAssembly compiles, multi-agent frameworks, and consensus security benchmarks.
            </p>
          </div>

          {/* Right: Interactive Newsletter Form */}
          <div className="w-full lg:max-w-md">
            <form onSubmit={handleSubscribe} className="flex flex-col gap-3 relative">
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="email"
                  value={email}
                  disabled={status === "success" || status === "submitting"}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your cryptographic or corporate email"
                  className={`w-full py-4.5 pl-12 pr-32 rounded-xl text-sm bg-slate-950 border text-white placeholder-gray-500 focus:outline-none transition-all ${
                    status === "error"
                      ? "border-rose-500/50 focus:ring-1 focus:ring-rose-500/30"
                      : "border-white/5 focus:border-cyan-400/50 focus:ring-1 focus:ring-cyan-400/30"
                  }`}
                />
                {/* Submit action button overlay */}
                <button
                  type="submit"
                  disabled={status === "success" || status === "submitting"}
                  className={`absolute right-2 top-1/2 -translate-y-1/2 px-5 py-2.5 rounded-lg text-xs font-bold transition-all duration-300 flex items-center gap-1.5 ${
                    status === "success"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : status === "submitting"
                        ? "bg-purple-500/20 text-purple-300 border border-purple-500/30 cursor-wait"
                        : "bg-white text-[#0B0F19] hover:bg-gradient-to-r hover:from-electric-purple hover:to-neon-cyan hover:text-white hover:scale-103 cursor-pointer active:scale-95 shadow-md shadow-black/30"
                  }`}
                >
                  {status === "success" ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Subscribed</span>
                    </>
                  ) : status === "submitting" ? (
                    <span>Encrypting...</span>
                  ) : (
                    <>
                      <span>Deploy Subscription</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>

              {/* Status messages indicator */}
              <div className="h-5">
                {status === "success" && (
                  <p className="text-[11px] font-mono font-bold text-emerald-400">
                    ✓ SECURE COMPILE COMPLETE. YOU HAVE SECURED THE TELEMETRY LINK.
                  </p>
                )}
                {status === "error" && (
                  <p className="text-[11px] font-mono font-bold text-rose-400">
                    ✕ INVALID PARAMETERS. COMPILATION REJECTED. CHECK EMAIL PATTERN.
                  </p>
                )}
                {status === "idle" && (
                  <p className="text-[10px] font-mono text-gray-500">
                    * By subscribing, you agree to secure transport protocol dispatches.
                  </p>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

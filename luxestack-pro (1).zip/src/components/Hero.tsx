import { useState, useEffect } from "react";
import { ArrowRight, Terminal, Activity, Sliders, Sparkles, Check, Play } from "lucide-react";
import { motion } from "motion/react";

export default function Hero() {
  const [activeTab, setActiveTab] = useState<"network" | "cache" | "console">("network");
  const [simSpike, setSimSpike] = useState(false);
  const [metrics, setMetrics] = useState({
    latency: 1.25,
    concurrency: 4802,
    nodes: 124,
    cacheHitRate: 98.4,
  });

  // Increment some numbers slightly over time to simulate a live telemetry board
  useEffect(() => {
    const timer = setInterval(() => {
      setMetrics((prev) => {
        const spikeMultiplier = simSpike ? 2.5 : 1;
        const targetLatency = simSpike ? 0.35 : 1.25 + (Math.random() - 0.5) * 0.1;
        const concurrencyDelta = Math.floor((Math.random() - 0.45) * 20) * spikeMultiplier;

        return {
          latency: parseFloat(Math.max(0.12, Math.min(3.5, targetLatency)).toFixed(2)),
          concurrency: Math.max(1200, Math.min(9999, prev.concurrency + concurrencyDelta)),
          nodes: prev.nodes,
          cacheHitRate: parseFloat(Math.max(92.1, Math.min(99.9, prev.cacheHitRate + (Math.random() - 0.49) * 0.15)).toFixed(1)),
        };
      });
    }, 1500);

    return () => clearInterval(timer);
  }, [simSpike]);

  // Handle simulation spike trigger
  const handleTriggerSpike = () => {
    setSimSpike(true);
    setTimeout(() => {
      setSimSpike(false);
    }, 5000);
  };

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-32 pb-24 overflow-hidden flex flex-col justify-center bg-[#0B0F19]"
    >
      {/* Background Radial Ambient Lights */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[100vw] h-[600px] bg-gradient-to-b from-purple-500/10 via-cyan-500/5 to-transparent rounded-full blur-[160px] pointer-events-none -z-10 animate-pulse-slow" />
      <div className="absolute top-1/3 -left-48 w-96 h-96 bg-purple-600/15 rounded-full blur-[140px] pointer-events-none -z-10 animate-float-slow" />
      <div className="absolute bottom-1/4 -right-48 w-96 h-96 bg-cyan-600/15 rounded-full blur-[140px] pointer-events-none -z-10 animate-float-delayed" />

      {/* Floating Animated Abstract Geometric Shapes */}
      <div className="absolute top-24 left-10 md:left-24 w-12 h-12 border border-purple-500/20 rounded-lg animate-float-slow opacity-60" />
      <div className="absolute bottom-1/4 left-16 md:left-32 w-16 h-16 border border-cyan-500/25 rounded-full animate-float-delayed opacity-50" />
      <div className="absolute top-1/3 right-12 md:right-28 w-14 h-14 border-t-2 border-r-2 border-purple-400/15 rounded-tr-3xl animate-float-reverse opacity-40" />
      <div className="absolute bottom-1/3 right-20 md:right-40 w-10 h-10 bg-gradient-to-br from-fuchsia-500/5 to-cyan-500/5 rounded-xl rotate-45 animate-float-slow opacity-70" />

      {/* Micro Grid Background Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.18),rgba(255,255,255,0))] pointer-events-none -z-20" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none -z-20" />

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
        {/* Left Side: Headline & CTAs */}
        <div className="lg:col-span-6 flex flex-col items-start gap-8 z-10" id="hero-content">
          {/* Accent Label */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold text-purple-300"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            <span>Introducing AURA 2.4 - Autonomous Edge Core</span>
          </motion.div>

          {/* Main Display Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white leading-[1.1]"
          >
            The Intelligence <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-electric-purple via-fuchsia-400 to-neon-cyan animate-gradient-x">
              Fabric for SaaS Labs
            </span>
          </motion.h1>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-base sm:text-lg text-gray-400 leading-relaxed max-w-xl"
          >
            Orchestrate micro-agent LLM workloads, bypass cold starts with local
            WebAssembly isolates, and settle distributed audit ledger states globally—all
            in under 5ms.
          </motion.p>

          {/* Feature Bullet Checklist */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6 text-sm text-gray-300 font-medium"
          >
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Sub-millisecond ledger settlements</span>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Zero-knowledge client gateways</span>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Self-healing Sandboxed execution</span>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>99.999% SLA High Availability</span>
            </div>
          </motion.div>

          {/* Dual CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto"
            id="hero-ctas"
          >
            <a
              href="#calculator"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection("#calculator");
              }}
              className="group relative flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl font-semibold text-white bg-gradient-to-r from-electric-purple to-neon-cyan shadow-[0_4px_25px_rgba(139,92,246,0.3)] hover:shadow-[0_4px_35px_rgba(6,182,212,0.5)] transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>Launch Live Planner</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#showcase"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection("#showcase");
              }}
              className="flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl font-semibold text-gray-300 hover:text-white border border-white/10 hover:border-white/20 bg-white/5 hover:bg-white/10 backdrop-blur-sm transition-all duration-300"
            >
              <Play className="w-4 h-4 text-cyan-400" />
              <span>Explore Showcase</span>
            </a>
          </motion.div>
        </div>

        {/* Right Side: Interactive Metrics Console Widget */}
        <div className="lg:col-span-6 z-10" id="hero-widget-container">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="w-full rounded-2xl glass-panel border border-white/10 overflow-hidden shadow-2xl relative group/card"
          >
            {/* Soft inner lighting */}
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-purple-500/40 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-cyan-500/5 pointer-events-none" />

            {/* Console Header Bar */}
            <div className="px-5 py-4 border-b border-white/5 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-500/80 block" />
                <span className="w-3 h-3 rounded-full bg-amber-500/80 block" />
                <span className="w-3 h-3 rounded-full bg-emerald-500/80 block" />
                <span className="text-xs font-mono text-gray-500 ml-2 tracking-wider">AURA-STATION-CONSOLE</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${simSpike ? "bg-purple-400 animate-ping" : "bg-cyan-400 animate-pulse"}`} />
                <span className="text-[10px] font-mono text-gray-400 font-medium">
                  {simSpike ? "OPTIMIZING THREADS" : "SECURE TELEMETRY ACTIVE"}
                </span>
              </div>
            </div>

            {/* Dashboard Workspace */}
            <div className="p-6 flex flex-col gap-6">
              {/* Telemetry Numbers Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-3 rounded-xl bg-slate-900/50 border border-white/5 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1 h-full bg-purple-500" />
                  <span className="text-[10px] uppercase font-mono text-gray-500 tracking-wider">Edge Latency</span>
                  <div className="text-lg font-display font-bold text-white mt-1">
                    {metrics.latency} <span className="text-xs text-purple-400">ms</span>
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/50 border border-white/5 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1 h-full bg-cyan-500" />
                  <span className="text-[10px] uppercase font-mono text-gray-500 tracking-wider">Active Swarms</span>
                  <div className="text-lg font-display font-bold text-white mt-1">
                    {metrics.concurrency.toLocaleString()}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/50 border border-white/5 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1 h-full bg-fuchsia-500" />
                  <span className="text-[10px] uppercase font-mono text-gray-500 tracking-wider">Cloud Nodes</span>
                  <div className="text-lg font-display font-bold text-white mt-1">
                    {metrics.nodes}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/50 border border-white/5 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500" />
                  <span className="text-[10px] uppercase font-mono text-gray-500 tracking-wider">Cache Hit</span>
                  <div className="text-lg font-display font-bold text-white mt-1">
                    {metrics.cacheHitRate} <span className="text-xs text-emerald-400">%</span>
                  </div>
                </div>
              </div>

              {/* Navigation Tabs for Demo Widget */}
              <div className="flex border-b border-white/5">
                <button
                  onClick={() => setActiveTab("network")}
                  className={`flex items-center gap-2 px-4 py-2 text-xs font-mono font-medium transition-all border-b-2 -mb-[1px] ${
                    activeTab === "network"
                      ? "text-cyan-400 border-cyan-400 bg-cyan-500/5"
                      : "text-gray-500 border-transparent hover:text-gray-300"
                  }`}
                >
                  <Activity className="w-3.5 h-3.5" />
                  Network Flow
                </button>
                <button
                  onClick={() => setActiveTab("cache")}
                  className={`flex items-center gap-2 px-4 py-2 text-xs font-mono font-medium transition-all border-b-2 -mb-[1px] ${
                    activeTab === "cache"
                      ? "text-purple-400 border-purple-400 bg-purple-500/5"
                      : "text-gray-500 border-transparent hover:text-gray-300"
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  Isolate Allocator
                </button>
                <button
                  onClick={() => setActiveTab("console")}
                  className={`flex items-center gap-2 px-4 py-2 text-xs font-mono font-medium transition-all border-b-2 -mb-[1px] ${
                    activeTab === "console"
                      ? "text-fuchsia-400 border-fuchsia-400 bg-fuchsia-500/5"
                      : "text-gray-500 border-transparent hover:text-gray-300"
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  Real-time Logs
                </button>
              </div>

              {/* Tab Workspace */}
              <div className="min-h-[160px] flex flex-col justify-between bg-slate-950/40 border border-white/5 rounded-xl p-4 font-mono text-xs">
                {activeTab === "network" && (
                  <div className="flex flex-col gap-3 h-full">
                    <div className="flex justify-between text-[11px] text-gray-500 border-b border-white/5 pb-1.5">
                      <span>DATACENTER INGRESS</span>
                      <span>SETTLEMENT DELTA</span>
                    </div>
                    {/* Visual bar waves */}
                    <div className="flex flex-col gap-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">ams-edge-01.aura.net</span>
                        <div className="flex items-center gap-1.5">
                          <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div className={`h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full transition-all duration-700 ${simSpike ? "w-[95%]" : "w-[65%]"}`} />
                          </div>
                          <span className={simSpike ? "text-purple-300" : "text-gray-400"}>{simSpike ? "0.08ms" : "0.85ms"}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">sfo-edge-02.aura.net</span>
                        <div className="flex items-center gap-1.5">
                          <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div className={`h-full bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full transition-all duration-700 ${simSpike ? "w-[85%]" : "w-[40%]"}`} />
                          </div>
                          <span className={simSpike ? "text-cyan-300" : "text-gray-400"}>{simSpike ? "0.12ms" : "1.44ms"}</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">tok-edge-03.aura.net</span>
                        <div className="flex items-center gap-1.5">
                          <div className="w-20 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div className={`h-full bg-gradient-to-r from-fuchsia-500 to-rose-500 rounded-full transition-all duration-700 ${simSpike ? "w-[98%]" : "w-[55%]"}`} />
                          </div>
                          <span className={simSpike ? "text-fuchsia-300" : "text-gray-400"}>{simSpike ? "0.15ms" : "2.05ms"}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "cache" && (
                  <div className="flex flex-col gap-3 h-full">
                    <span className="text-[11px] text-purple-400 tracking-wider">COGNITIVE AGENT ALLOCATION MATRIX</span>
                    <div className="grid grid-cols-6 gap-2">
                      {Array.from({ length: 18 }).map((_, i) => {
                        const active = i % 3 === 0 || simSpike;
                        const stateColor = simSpike 
                          ? "bg-purple-500 shadow-[0_0_8px_rgba(139,92,246,0.6)]" 
                          : active 
                            ? "bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.4)]" 
                            : "bg-slate-800 border border-white/5";
                        return (
                          <div
                            key={i}
                            className={`h-6 rounded flex items-center justify-center text-[10px] font-bold text-[#0B0F19] transition-all duration-500 ${stateColor}`}
                          >
                            {active ? `W${i+1}` : ""}
                          </div>
                        );
                      })}
                    </div>
                    <span className="text-[10px] text-gray-500 mt-1">WASM execution isolates scale down instantly when idle.</span>
                  </div>
                )}

                {activeTab === "console" && (
                  <div className="flex flex-col gap-1.5 h-full overflow-y-auto font-mono text-[10px] leading-relaxed text-gray-400">
                    <div>
                      <span className="text-gray-600">[{new Date().toLocaleTimeString()}]</span>{" "}
                      <span className="text-cyan-400">SYSTEM:</span> Initialized secure connection cluster.
                    </div>
                    <div>
                      <span className="text-gray-600">[{new Date().toLocaleTimeString()}]</span>{" "}
                      <span className="text-purple-400">MEMORY:</span> Indexed 42,800 semantic vectors into high-speed caching db.
                    </div>
                    {simSpike && (
                      <div className="text-fuchsia-400 animate-pulse">
                        <span className="text-gray-600">[{new Date().toLocaleTimeString()}]</span>{" "}
                        <span className="font-bold">SYSTEM SPIKE TRIGGERED:</span> Multi-core router executing hot compilation isolates. Latency dropped globally.
                      </div>
                    )}
                    <div>
                      <span className="text-gray-600">[{new Date().toLocaleTimeString()}]</span>{" "}
                      <span className="text-emerald-400">SECURITY:</span> verified zero-knowledge authorization block certificate.
                    </div>
                  </div>
                )}

                {/* Bottom interactive trigger action */}
                <div className="flex items-center justify-between mt-4 border-t border-white/5 pt-3">
                  <span className="text-[10px] text-gray-500">Click to run interactive stress simulation:</span>
                  <button
                    onClick={handleTriggerSpike}
                    disabled={simSpike}
                    className={`px-3 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all duration-300 ${
                      simSpike
                        ? "bg-purple-500/20 text-purple-300 cursor-not-allowed border border-purple-500/30"
                        : "bg-white/10 hover:bg-white/20 text-white border border-white/10 active:scale-[0.95]"
                    }`}
                  >
                    {simSpike ? "Simulating Spike..." : "Trigger Optimization"}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

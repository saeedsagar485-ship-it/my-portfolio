import { useState, useEffect } from "react";
import { Menu, X, Cpu, Github, Globe } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Hero", href: "#hero" },
    { name: "Features", href: "#features" },
    { name: "Showcase", href: "#showcase" },
    { name: "ROI Planner", href: "#calculator" },
    { name: "Reviews", href: "#reviews" },
  ];

  const handleLinkClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <header
        id="app-navbar"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "py-4 bg-[#0B0F19]/80 backdrop-blur-md border-b border-white/5 shadow-[0_4px_30px_rgba(0,0,0,0.4)]"
            : "py-6 bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <a
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              handleLinkClick("#hero");
            }}
            className="flex items-center gap-2.5 group"
            id="nav-logo"
          >
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-electric-purple to-neon-cyan p-[1px] transition-transform duration-500 group-hover:rotate-12">
              <div className="w-full h-full bg-[#0B0F19] rounded-[11px] flex items-center justify-center">
                <Cpu className="w-5 h-5 text-cyan-400 group-hover:text-purple-400 transition-colors duration-300" />
              </div>
              {/* Glow Behind Logo */}
              <div className="absolute -inset-0.5 bg-gradient-to-r from-electric-purple to-neon-cyan rounded-xl blur-md opacity-30 group-hover:opacity-60 transition-opacity duration-300 -z-10" />
            </div>
            <span className="font-display font-bold text-xl tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-100 to-gray-300">
              AURA
            </span>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8" id="desktop-nav">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(link.href);
                }}
                className="relative text-sm font-medium text-gray-400 hover:text-white transition-colors duration-300 py-1.5 group"
              >
                {link.name}
                {/* Modern slide-out underline hover animation */}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-electric-purple to-neon-cyan transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Desktop Call to Actions */}
          <div className="hidden md:flex items-center gap-4" id="desktop-ctas">
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl border border-white/10 hover:border-white/25 text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 transition-all duration-300"
              title="View Source on GitHub"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href="#calculator"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick("#calculator");
              }}
              className="relative group overflow-hidden px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-all duration-300"
            >
              {/* Gradient border effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-electric-purple to-neon-cyan rounded-xl" />
              {/* Inner body on hover shift */}
              <div className="absolute inset-[1px] bg-[#0B0F19] rounded-[11px] group-hover:opacity-0 transition-opacity duration-300" />
              <span className="relative z-10 bg-clip-text group-hover:text-[#0B0F19] bg-gradient-to-r from-white to-gray-200 transition-colors duration-300">
                Get Started
              </span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2.5 rounded-xl border border-white/10 text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
            aria-label="Toggle menu"
            id="mobile-menu-toggle"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="fixed inset-0 z-40 bg-[#0B0F19]/95 backdrop-blur-xl md:hidden pt-28 px-6 flex flex-col gap-8 border-b border-white/5 shadow-2xl"
            id="mobile-menu-drawer"
          >
            {/* Background glowing gradient orbs inside mobile drawer */}
            <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-electric-purple/20 rounded-full blur-[100px] -z-10" />
            <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-neon-cyan/15 rounded-full blur-[100px] -z-10" />

            <div className="flex flex-col gap-6 text-center">
              {navLinks.map((link, idx) => (
                <motion.a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleLinkClick(link.href);
                  }}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="text-lg font-medium text-gray-300 hover:text-white transition-colors"
                >
                  {link.name}
                </motion.a>
              ))}
            </div>

            <div className="h-[1px] bg-white/5 my-2" />

            <div className="flex flex-col gap-4">
              <a
                href="#calculator"
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick("#calculator");
                }}
                className="w-full text-center py-3.5 rounded-xl font-semibold bg-gradient-to-r from-electric-purple to-neon-cyan text-white shadow-lg shadow-purple-500/20 hover:shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                Get Started Free
              </a>
              <div className="flex justify-center gap-6 mt-2 text-gray-400">
                <a href="https://github.com" target="_blank" rel="noreferrer" className="hover:text-white">
                  <Github className="w-5 h-5" />
                </a>
                <a href="https://google.com" target="_blank" rel="noreferrer" className="hover:text-white">
                  <Globe className="w-5 h-5" />
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

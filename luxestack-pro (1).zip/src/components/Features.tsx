import { useState } from "react";
import { 
  BrainCircuit, 
  ShieldCheck, 
  Zap, 
  Users, 
  Fingerprint, 
  Globe, 
  Copy, 
  Check, 
  LineChart, 
  Activity, 
  ArrowUpRight 
} from "lucide-react";
import { FEATURES_DATA } from "../data";
import { Feature } from "../types";

// Icon mapper to dynamically render Lucide icons
const IconComponent = ({ name, className }: { name: string; className?: string }) => {
  switch (name) {
    case "BrainCircuit":
      return <BrainCircuit className={className} />;
    case "ShieldCheck":
      return <ShieldCheck className={className} />;
    case "Zap":
      return <Zap className={className} />;
    case "Users":
      return <Users className={className} />;
    case "Fingerprint":
      return <Fingerprint className={className} />;
    case "Globe":
      return <Globe className={className} />;
    default:
      return <Activity className={className} />;
  }
};

export default function Features() {
  const [copiedCode, setCopiedCode] = useState(false);
  const [resolvedConflict, setResolvedConflict] = useState(false);
  const [activeTelemetry, setActiveTelemetry] = useState<"A" | "B" | "C">("A");

  const sampleCode = `import { AuraNode } from "@aura/core";

const node = new AuraNode({
  gateway: "ams-01",
  isolatePath: "./index.wasm"
});

await node.deploy();`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(sampleCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const triggerConflictResolve = () => {
    setResolvedConflict(true);
    setTimeout(() => setResolvedConflict(false), 3000);
  };

  return (
    <section id="features" className="py-24 relative bg-[#0B0F19] overflow-hidden">
      {/* Background radial soft light blobs */}
      <div className="absolute top-1/2 left-10 w-96 h-96 bg-purple-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-20 flex flex-col items-center gap-4">
          <span className="text-xs uppercase tracking-widest font-semibold font-mono bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">
            ENGINEERING CAPABILITIES
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            High-Performance Architecture
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-electric-purple to-neon-cyan rounded-full my-1" />
          <p className="text-gray-400 text-sm sm:text-base leading-relaxed">
            Eliminate operational overhead with standard pre-configured edge modules. Scaled, integrated, and hardened right out of the box.
          </p>
        </div>

        {/* Bento Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-[250px] lg:auto-rows-[220px]">
          {FEATURES_DATA.map((feature: Feature) => {
            // We can style individual features based on their interactive features to make a true Bento Grid!
            let gridClasses = "col-span-1 row-span-1";
            if (feature.interactiveType === "stats") {
              gridClasses = "col-span-1 md:col-span-2 row-span-2 lg:row-span-2";
            } else if (feature.interactiveType === "code") {
              gridClasses = "col-span-1 md:col-span-2 row-span-2 lg:col-span-1 lg:row-span-2";
            } else if (feature.interactiveType === "chart") {
              gridClasses = "col-span-1 md:col-span-1 row-span-2 lg:row-span-2";
            } else if (feature.interactiveType === "toggle") {
              gridClasses = "col-span-1 md:col-span-1 row-span-1 lg:col-span-1 lg:row-span-1";
            }

            return (
              <div
                key={feature.id}
                id={feature.id}
                className={`glass-panel glass-panel-hover rounded-2xl p-6 flex flex-col justify-between relative group overflow-hidden ${gridClasses}`}
              >
                {/* Background glowing gradient spot inside card */}
                <div className={`absolute -right-12 -top-12 w-28 h-28 bg-gradient-to-br ${feature.gradient} rounded-full blur-[40px] opacity-10 group-hover:opacity-25 transition-opacity duration-500`} />

                {/* Card Header Info */}
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${feature.gradient} text-[#0B0F19] transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6`}>
                      <IconComponent name={feature.iconName} className="w-5 h-5 text-white" />
                    </div>
                    {feature.badge && (
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-white/5 border border-white/10 text-gray-300">
                        {feature.badge}
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="font-display font-bold text-lg text-white group-hover:text-cyan-300 transition-colors duration-300 flex items-center gap-1.5">
                      {feature.title}
                      <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-300 text-cyan-400" />
                    </h3>
                    <p className="text-gray-400 text-xs sm:text-sm mt-1.5 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>

                {/* Interactive Feature Elements (True Craftsmanship) */}

                {/* Stats Feature Interactive Grid */}
                {feature.interactiveType === "stats" && (
                  <div className="mt-4 grid grid-cols-3 gap-3 border-t border-white/5 pt-4">
                    <button
                      onClick={() => setActiveTelemetry("A")}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        activeTelemetry === "A"
                          ? "bg-purple-500/10 border-purple-500/30 text-white"
                          : "bg-slate-900/30 border-white/5 text-gray-400 hover:border-white/10"
                      }`}
                    >
                      <span className="text-[10px] block font-mono text-gray-500">THREAD ALPHA</span>
                      <span className="text-sm font-bold font-display mt-0.5 block">99.85%</span>
                    </button>
                    <button
                      onClick={() => setActiveTelemetry("B")}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        activeTelemetry === "B"
                          ? "bg-fuchsia-500/10 border-fuchsia-500/30 text-white"
                          : "bg-slate-900/30 border-white/5 text-gray-400 hover:border-white/10"
                      }`}
                    >
                      <span className="text-[10px] block font-mono text-gray-500">THREAD BETA</span>
                      <span className="text-sm font-bold font-display mt-0.5 block">0.14ms</span>
                    </button>
                    <button
                      onClick={() => setActiveTelemetry("C")}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        activeTelemetry === "C"
                          ? "bg-cyan-500/10 border-cyan-500/30 text-white"
                          : "bg-slate-900/30 border-white/5 text-gray-400 hover:border-white/10"
                      }`}
                    >
                      <span className="text-[10px] block font-mono text-gray-500">THREAD GAMMA</span>
                      <span className="text-sm font-bold font-display mt-0.5 block">1.8GB/s</span>
                    </button>
                  </div>
                )}

                {/* Code Feature Copy Paste Block */}
                {feature.interactiveType === "code" && (
                  <div className="mt-4 bg-slate-950/80 border border-white/5 rounded-xl p-3.5 relative font-mono text-[11px] text-gray-300 leading-relaxed group/code">
                    <pre className="overflow-x-auto scrollbar-none">{sampleCode}</pre>
                    <button
                      onClick={handleCopyCode}
                      className="absolute top-2 right-2 p-1.5 rounded-lg bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                      title="Copy deployment script"
                    >
                      {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                )}

                {/* Consensus Block visual chart */}
                {feature.interactiveType === "chart" && (
                  <div className="mt-4 bg-slate-950/50 border border-white/5 rounded-xl p-4 flex flex-col justify-between h-[110px] font-mono text-[10px]">
                    <div className="flex justify-between items-center text-gray-500">
                      <span>VERIFIED LEDGER BLOCKS</span>
                      <span className="text-emerald-400 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                        SYNCED
                      </span>
                    </div>
                    {/* Simulated visual bar charts */}
                    <div className="flex items-end gap-1.5 h-10 px-2">
                      {[30, 45, 25, 60, 40, 80, 50, 70, 95, 60, 40].map((h, index) => (
                        <div key={index} className="flex-1 bg-slate-800 rounded-sm h-full flex items-end">
                          <div
                            style={{ height: `${h}%` }}
                            className="w-full bg-gradient-to-t from-cyan-500 to-teal-400 rounded-sm transition-all duration-1000 group-hover:brightness-125"
                          />
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between text-gray-600 text-[9px]">
                      <span>SEC -10s</span>
                      <span>CURRENT BLOCK: #284,912</span>
                    </div>
                  </div>
                )}

                {/* Collaborative Conflict Resolution Button */}
                {feature.interactiveType === "toggle" && (
                  <div className="mt-3 flex items-center justify-between border-t border-white/5 pt-3">
                    <span className="text-[10px] font-mono text-gray-500">Visual Sync Conflict:</span>
                    <button
                      onClick={triggerConflictResolve}
                      className={`px-3 py-1 rounded-lg text-[10px] font-bold font-mono transition-all uppercase ${
                        resolvedConflict
                          ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                          : "bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 active:scale-[0.95]"
                      }`}
                    >
                      {resolvedConflict ? "CRDT SOLVED" : "RESOLVE CONFLICT"}
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

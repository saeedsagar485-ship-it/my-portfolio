import { useState, useEffect } from "react";
import { Check, Calculator, TrendingUp, PiggyBank, HelpCircle, Server, RefreshCw } from "lucide-react";
import { PRICING_PLANS } from "../data";

export default function PricingCalculator() {
  const [activeTab, setActiveTab] = useState<"plans" | "roi">("plans");
  const [isAnnual, setIsAnnual] = useState(false);

  // ROI Calculator states
  const [requests, setRequests] = useState<number>(10); // Millions of requests per month
  const [agents, setAgents] = useState<number>(15); // Number of active agents
  const [calculatedSavings, setCalculatedSavings] = useState({
    auraCost: 99,
    traditionalCost: 820,
    netSavings: 721,
    multiplier: "8.3x",
    recommendedPlan: "Professional"
  });

  // Dynamically calculate ROI whenever parameters change
  useEffect(() => {
    // 1M requests = $5 aura, $45 traditional
    // 1 agent = $3 aura, $25 traditional
    const baseAura = requests * 5.2 + agents * 3.5;
    const baseTraditional = requests * 48.5 + agents * 28.0;

    let plan = "Developer";
    let auraPrice = 29;

    if (baseAura > 250 || requests > 50 || agents > 30) {
      plan = "Enterprise";
      auraPrice = 299;
    } else if (baseAura > 50 || requests > 10 || agents > 10) {
      plan = "Professional";
      auraPrice = 99;
    } else {
      plan = "Developer";
      auraPrice = 29;
    }

    // Aura edge compiles bypass heavy container overhead, keeping cost static
    const netSavings = Math.max(0, Math.floor(baseTraditional - auraPrice));
    const multiplier = (baseTraditional / auraPrice).toFixed(1) + "x";

    setCalculatedSavings({
      auraCost: auraPrice,
      traditionalCost: Math.floor(baseTraditional),
      netSavings,
      multiplier,
      recommendedPlan: plan
    });
  }, [requests, agents]);

  return (
    <section id="calculator" className="py-24 relative bg-[#0B0F19] overflow-hidden">
      {/* Background soft glowing orbs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[500px] bg-purple-500/5 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 flex flex-col items-center gap-4">
          <span className="text-xs uppercase tracking-widest font-semibold font-mono bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">
            PRICING & FEASIBILITY PLANNING
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Predictable Scaling Architectures
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-electric-purple to-neon-cyan rounded-full my-1" />
          <p className="text-gray-400 text-sm sm:text-base leading-relaxed">
            Choose a pre-packaged high-performance plan or adjust our dynamic calculator to estimate monthly cloud savings.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center justify-center mb-16">
          <div className="p-1 rounded-2xl bg-slate-900 border border-white/5 flex gap-1">
            <button
              onClick={() => setActiveTab("plans")}
              className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                activeTab === "plans"
                  ? "bg-gradient-to-r from-electric-purple to-neon-cyan text-white shadow-md shadow-purple-500/10"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              <Server className="w-4 h-4" />
              Pricing Plans
            </button>
            <button
              onClick={() => setActiveTab("roi")}
              className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-300 ${
                activeTab === "roi"
                  ? "bg-gradient-to-r from-electric-purple to-neon-cyan text-white shadow-md shadow-purple-500/10"
                  : "text-gray-400 hover:text-white"
              }`}
            >
              <Calculator className="w-4 h-4" />
              Dynamic ROI Planner
            </button>
          </div>
        </div>

        {/* Dynamic Display Area */}
        <div className="transition-all duration-500">
          {activeTab === "plans" ? (
            <div id="pricing-plans-tab">
              {/* Annual Toggle */}
              <div className="flex items-center justify-center gap-4 mb-12">
                <span className={`text-sm font-semibold transition-colors ${!isAnnual ? "text-white" : "text-gray-500"}`}>
                  Monthly Billing
                </span>
                <button
                  onClick={() => setIsAnnual(!isAnnual)}
                  className="w-12 h-6.5 rounded-full bg-slate-800 border border-white/10 p-0.5 flex transition-colors relative"
                  aria-label="Toggle annual billing"
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-gradient-to-r from-electric-purple to-neon-cyan transition-transform ${
                      isAnnual ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
                <span className={`text-sm font-semibold transition-colors flex items-center gap-1.5 ${isAnnual ? "text-cyan-400" : "text-gray-500"}`}>
                  Annual Billing
                  <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-[10px] font-bold text-cyan-300 border border-cyan-500/20">
                    Save 20%
                  </span>
                </span>
              </div>

              {/* Pricing Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
                {PRICING_PLANS.map((plan) => {
                  // Calculate dynamic annual billing price
                  const basePriceInt = parseInt(plan.price.replace("$", ""));
                  const finalPrice = isAnnual ? `$${Math.floor(basePriceInt * 0.8)}` : plan.price;

                  return (
                    <div
                      key={plan.id}
                      className={`glass-panel rounded-2xl p-8 flex flex-col justify-between relative group/tier ${
                        plan.isPopular
                          ? "border-purple-500/30 bg-purple-950/10 shadow-[0_15px_30px_rgba(139,92,246,0.1)] scale-102 lg:scale-105 z-10"
                          : "border-white/5"
                      }`}
                    >
                      {/* Popular ribbon */}
                      {plan.isPopular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                          <span className="px-3.5 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-gradient-to-r from-electric-purple to-neon-cyan text-white shadow-md shadow-purple-500/20 flex items-center gap-1">
                            <TrendingUp className="w-3.5 h-3.5" />
                            Most Popular Choice
                          </span>
                        </div>
                      )}

                      {/* Header */}
                      <div className="flex flex-col gap-6">
                        <div className="flex flex-col gap-2">
                          <h3 className="font-display font-bold text-xl text-white group-hover/tier:text-cyan-300 transition-colors">
                            {plan.name}
                          </h3>
                          <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                            {plan.description}
                          </p>
                        </div>

                        <div className="flex items-baseline gap-1 py-2 border-y border-white/5">
                          <span className="text-4xl font-display font-extrabold text-white tracking-tight">
                            {finalPrice}
                          </span>
                          <span className="text-sm font-semibold text-gray-500">
                            / {plan.period}
                          </span>
                        </div>

                        {/* Checklist */}
                        <div className="flex flex-col gap-3.5 my-3">
                          {plan.features.map((feat, index) => (
                            <div key={index} className="flex items-start gap-3 text-sm text-gray-300">
                              <div className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 mt-0.5 shrink-0">
                                <Check className="w-3.5 h-3.5" />
                              </div>
                              <span className="leading-tight">{feat}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Button Action */}
                      <button
                        onClick={() => alert(`Redirecting to payment setup for: ${plan.name} Plan`)}
                        className={`w-full py-3.5 rounded-xl text-center text-sm font-semibold transition-all duration-300 mt-8 active:scale-[0.98] ${
                          plan.isPopular
                            ? "bg-gradient-to-r from-electric-purple to-neon-cyan text-white shadow-lg shadow-purple-500/20 hover:scale-[1.02]"
                            : "bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-white/5 hover:border-white/10"
                        }`}
                      >
                        {plan.buttonText}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* ROI Interactive Calculator Panel */
            <div id="dynamic-roi-panel" className="w-full max-w-5xl mx-auto rounded-2xl glass-panel border border-white/10 p-6 sm:p-10 shadow-2xl relative">
              {/* Visual accents */}
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5 pointer-events-none rounded-2xl" />

              <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center">
                {/* Sliders Input Area (Col 7) */}
                <div className="md:col-span-7 flex flex-col gap-8">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
                      <Calculator className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-lg text-white">Scale Parameter Estimator</h3>
                      <p className="text-xs text-gray-500 font-mono">ADJUST SLIDERS FOR MONTHLY TELEMETRY BUDGET</p>
                    </div>
                  </div>

                  {/* Slider 1: API requests */}
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-sm text-gray-300">Monthly Ingress requests:</span>
                      <span className="text-sm font-mono text-cyan-400">{requests} Million</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="100"
                      value={requests}
                      onChange={(e) => setRequests(parseInt(e.target.value))}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400 transition-all focus:outline-none"
                    />
                    <div className="flex justify-between font-mono text-[10px] text-gray-500">
                      <span>1M requests</span>
                      <span>50M requests</span>
                      <span>100M requests</span>
                    </div>
                  </div>

                  {/* Slider 2: AI Agents */}
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-sm text-gray-300">Active Multi-Agent Swarms:</span>
                      <span className="text-sm font-mono text-purple-400">{agents} agents</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="50"
                      value={agents}
                      onChange={(e) => setAgents(parseInt(e.target.value))}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400 transition-all focus:outline-none"
                    />
                    <div className="flex justify-between font-mono text-[10px] text-gray-500">
                      <span>1 agent</span>
                      <span>25 agents</span>
                      <span>50 agents</span>
                    </div>
                  </div>

                  <div className="text-xs text-gray-400 flex items-start gap-2.5 bg-slate-950/40 p-4 rounded-xl border border-white/5">
                    <HelpCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">
                      * Aura eliminates standard continuous container runtime costs by executing short-lived compiles instantly inside high-speed WebAssembly sandboxes, ensuring predictable horizontal scaling.
                    </p>
                  </div>
                </div>

                {/* Savings Metrics Area (Col 5) */}
                <div className="md:col-span-5 p-6 rounded-2xl bg-slate-950/60 border border-white/5 flex flex-col gap-6 justify-between relative overflow-hidden">
                  {/* Glowing light spot */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

                  <div className="flex flex-col gap-4">
                    <span className="text-[10px] uppercase font-mono tracking-widest font-bold text-emerald-400 flex items-center gap-1.5">
                      <PiggyBank className="w-4 h-4 animate-bounce" />
                      MONTHLY FEASIBILITY OUTPUT
                    </span>

                    {/* Massive Savings Display */}
                    <div className="py-2">
                      <span className="text-xs text-gray-400 font-medium block">Estimated Net Savings:</span>
                      <div className="text-3xl sm:text-4xl font-display font-extrabold text-white mt-1 tracking-tight flex items-baseline gap-1">
                        ${calculatedSavings.netSavings.toLocaleString()}
                        <span className="text-sm font-semibold text-emerald-400">/ mo</span>
                      </div>
                    </div>
                  </div>

                  <div className="h-[1px] bg-white/5" />

                  {/* Stats compare checklist */}
                  <div className="flex flex-col gap-3 font-mono text-xs">
                    <div className="flex justify-between text-gray-400">
                      <span>Traditional Cloud Hosting:</span>
                      <span className="text-gray-300 line-through">${calculatedSavings.traditionalCost}/mo</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Aura Edge Environment:</span>
                      <span className="text-cyan-400 font-semibold">${calculatedSavings.auraCost}/mo</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Efficiency Multiplier:</span>
                      <span className="text-purple-400 font-bold">{calculatedSavings.multiplier} ROI</span>
                    </div>
                  </div>

                  <div className="h-[1px] bg-white/5" />

                  {/* Recommended Plan Badge */}
                  <div className="flex items-center justify-between bg-white/5 rounded-xl p-3.5 border border-white/5">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-gray-500 font-mono">RECOMMENDED PLAN</span>
                      <span className="text-sm font-bold text-white mt-0.5">{calculatedSavings.recommendedPlan}</span>
                    </div>
                    <button
                      onClick={() => {
                        setActiveTab("plans");
                        // Let users visual focus to plans
                        setTimeout(() => {
                          const element = document.querySelector("#calculator");
                          if (element) {
                            element.scrollIntoView({ behavior: "smooth" });
                          }
                        }, 200);
                      }}
                      className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-[#0B0F19] bg-gradient-to-r from-electric-purple to-neon-cyan hover:scale-105 active:scale-95 transition-all"
                    >
                      Subscribe
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

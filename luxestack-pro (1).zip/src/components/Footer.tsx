import React from "react";
import { Cpu, Github, Twitter, Youtube, MessageSquare, ArrowUp, Shield } from "lucide-react";

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const footerColumns = [
    {
      title: "Core Services",
      links: [
        { name: "WASM Sandbox Isolate", href: "#features" },
        { name: "Consensus Ledger Protocol", href: "#features" },
        { name: "Multi-Agent swarms", href: "#features" },
        { name: "Global Edge Router", href: "#features" },
        { name: "Observability Telemetry", href: "#features" },
      ],
    },
    {
      title: "Platform Engine",
      links: [
        { name: "System Status Nodes", href: "#hero" },
        { name: "Developer Documentation", href: "#showcase" },
        { name: "API Specifications Suite", href: "#showcase" },
        { name: "Cryptographic Handshake", href: "#reviews" },
        { name: "Vulnerability Auditing", href: "#reviews" },
      ],
    },
    {
      title: "Corporate Governance",
      links: [
        { name: "Terms of Compliance", href: "#" },
        { name: "Privacy Protocols", href: "#" },
        { name: "Venture Licensing", href: "#" },
        { name: "BGP Path Agreement", href: "#" },
        { name: "Hardware Trust HSM", href: "#" },
      ],
    },
  ];

  const handleLinkClick = (e: React.MouseEvent, href: string) => {
    if (href.startsWith("#")) {
      e.preventDefault();
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <footer id="app-footer" className="relative bg-slate-950/80 border-t border-white/5 pt-20 pb-12 z-10 overflow-hidden">
      {/* Background soft glowing spot */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-72 bg-purple-500/5 rounded-full blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Top 4-Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 mb-16">
          {/* Col 1: Brand & Socials (Col size 4) */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <a
              href="#hero"
              onClick={(e) => handleLinkClick(e, "#hero")}
              className="flex items-center gap-2.5 group"
            >
              <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-electric-purple to-neon-cyan p-[1px] transition-transform duration-500 group-hover:rotate-12">
                <div className="w-full h-full bg-[#0B0F19] rounded-[11px] flex items-center justify-center">
                  <Cpu className="w-4.5 h-4.5 text-cyan-400 group-hover:text-purple-400" />
                </div>
              </div>
              <span className="font-display font-bold text-lg tracking-wider text-white">AURA</span>
            </a>

            <p className="text-gray-400 text-xs sm:text-sm leading-relaxed max-w-xs">
              A premium, secure infrastructure platform designed for modular scaling, sub-millisecond ledgers, and cognitive agent execution.
            </p>

            {/* Social Icons with scale, hover shift and title */}
            <div className="flex items-center gap-3">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg border border-white/5 text-gray-500 hover:text-white hover:border-white/15 bg-white/5 transition-all"
                title="GitHub"
              >
                <Github className="w-4.5 h-4.5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg border border-white/5 text-gray-500 hover:text-white hover:border-white/15 bg-white/5 transition-all"
                title="Twitter"
              >
                <Twitter className="w-4.5 h-4.5" />
              </a>
              <a
                href="https://discord.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg border border-white/5 text-gray-500 hover:text-white hover:border-white/15 bg-white/5 transition-all"
                title="Discord"
              >
                <MessageSquare className="w-4.5 h-4.5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg border border-white/5 text-gray-500 hover:text-white hover:border-white/15 bg-white/5 transition-all"
                title="YouTube"
              >
                <Youtube className="w-4.5 h-4.5" />
              </a>
            </div>
          </div>

          {/* Cols 2-4: Service links (Col size 8) */}
          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-8">
            {footerColumns.map((col) => (
              <div key={col.title} className="flex flex-col gap-4">
                <h4 className="font-display font-bold text-xs uppercase tracking-wider text-white">
                  {col.title}
                </h4>
                <ul className="flex flex-col gap-2.5">
                  {col.links.map((link) => (
                    <li key={link.name}>
                      <a
                        href={link.href}
                        onClick={(e) => handleLinkClick(e, link.href)}
                        className="text-xs sm:text-sm text-gray-400 hover:text-white transition-colors duration-200"
                      >
                        {link.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Divider line */}
        <div className="h-[1px] bg-white/5 mb-8" />

        {/* Bottom Metadata & Copyright & Scroll Up */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left text-xs text-gray-500 font-mono">
            <span>© {new Date().getFullYear()} AURA TECHNOLOGIES INC.</span>
            <span className="hidden sm:inline text-gray-800">|</span>
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-cyan-500/70" />
              SECURE TRANSPORT HANDSHAKE ENABLED
            </span>
          </div>

          <button
            onClick={handleScrollToTop}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-white/5 hover:border-white/15 bg-white/5 hover:bg-white/10 text-xs font-semibold text-gray-400 hover:text-white transition-all duration-300 active:scale-[0.95] group"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform text-cyan-400" />
          </button>
        </div>
      </div>
    </footer>
  );
}

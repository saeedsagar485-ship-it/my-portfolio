import React, { useState } from "react";
import { Star, MessageSquarePlus, Smile, Building, ShieldCheck, CheckCircle2 } from "lucide-react";
import { TESTIMONIALS_DATA } from "../data";
import { Testimonial } from "../types";

export default function Testimonials() {
  const [reviews, setReviews] = useState<Testimonial[]>(TESTIMONIALS_DATA);
  const [showAddForm, setShowAddForm] = useState(false);

  // Review Form States
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [company, setCompany] = useState("");
  const [content, setContent] = useState("");
  const [rating, setRating] = useState(5);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !content || !role || !company) {
      alert("Please fill in all fields to submit your review.");
      return;
    }

    const newReview: Testimonial = {
      id: `user-rev-${Date.now()}`,
      name,
      role,
      company,
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=150&auto=format&fit=crop", // Elegant default avatar
      content,
      rating,
      date: "Today"
    };

    setReviews([newReview, ...reviews]);
    setFormSubmitted(true);

    // Reset Form
    setTimeout(() => {
      setName("");
      setRole("");
      setCompany("");
      setContent("");
      setRating(5);
      setFormSubmitted(false);
      setShowAddForm(false);
    }, 2000);
  };

  return (
    <section id="reviews" className="py-24 relative bg-[#0B0F19] overflow-hidden">
      {/* Background glowing light gradient */}
      <div className="absolute top-1/4 left-0 w-80 h-80 bg-purple-600/5 rounded-full blur-[100px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 right-0 w-80 h-80 bg-cyan-600/5 rounded-full blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-16 flex flex-col items-center gap-4">
          <span className="text-xs uppercase tracking-widest font-semibold font-mono bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">
            CLIENT ADVOCACY
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
            Verified Operational Impact
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-electric-purple to-neon-cyan rounded-full my-1" />
          <p className="text-gray-400 text-sm sm:text-base leading-relaxed">
            Read transparent reviews compiled directly from enterprise architects, venture engineers, and developers globally.
          </p>
        </div>

        {/* Dynamic Reviews Board Panel */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start">
          {/* Left Column: Testimonials Cards Grid (Col 8) */}
          <div className="md:col-span-8 flex flex-col gap-6" id="reviews-cards-list">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="glass-panel glass-panel-hover rounded-2xl p-6 flex flex-col justify-between relative group/card border-white/5"
                >
                  {/* Verified check badge for customer satisfaction */}
                  <div className="absolute top-6 right-6 text-cyan-400 opacity-60 group-hover/card:opacity-100 transition-opacity">
                    <ShieldCheck className="w-5 h-5" />
                  </div>

                  <div>
                    {/* Stars */}
                    <div className="flex gap-1 mb-4 text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < rev.rating ? "fill-amber-400" : "text-slate-700"}`}
                        />
                      ))}
                    </div>

                    {/* Content text */}
                    <p className="text-gray-300 text-sm leading-relaxed mb-6 italic">
                      "{rev.content}"
                    </p>
                  </div>

                  {/* Customer Identity profile footer */}
                  <div className="flex items-center gap-4.5 border-t border-white/5 pt-4">
                    <div className="w-11 h-11 rounded-full overflow-hidden border border-white/10 shrink-0">
                      <img
                        src={rev.avatar}
                        alt={rev.name}
                        referrerPolicy="no-referrer"
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-white group-hover/card:text-cyan-300 transition-colors">
                        {rev.name}
                      </h4>
                      <p className="text-[11px] text-gray-500 font-mono mt-0.5 uppercase tracking-wide">
                        {rev.role} at <span className="text-purple-300">{rev.company}</span>
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Empty reviews state if any (not possible in ordinary flow) */}
            {reviews.length === 0 && (
              <div className="p-8 text-center bg-slate-900/30 border border-white/5 rounded-2xl text-gray-400">
                No active testimonials found. Be the first to add yours!
              </div>
            )}
          </div>

          {/* Right Column: Interaction sidebar (Col 4) */}
          <div className="md:col-span-4 shrink-0" id="reviews-interaction-sidebar">
            <div className="glass-panel rounded-2xl p-6 sm:p-8 border-white/10 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-purple-500/40 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-cyan-500/5 pointer-events-none rounded-2xl" />

              {!showAddForm ? (
                /* Primary Sidebar Callout */
                <div className="flex flex-col gap-6 text-center md:text-left">
                  <div className="flex justify-center md:justify-start">
                    <div className="p-3.5 rounded-2xl bg-purple-500/15 text-purple-400">
                      <MessageSquarePlus className="w-6 h-6 animate-pulse" />
                    </div>
                  </div>

                  <div>
                    <h3 className="font-display font-bold text-lg text-white">Join the Conversation</h3>
                    <p className="text-xs sm:text-sm text-gray-400 mt-2 leading-relaxed">
                      Are you running Aura nodes? Contribute your engineering feedback or operational telemetry case metrics to our public catalog.
                    </p>
                  </div>

                  <button
                    onClick={() => setShowAddForm(true)}
                    className="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-xl font-bold text-[#0B0F19] bg-gradient-to-r from-electric-purple to-neon-cyan hover:scale-102 active:scale-95 transition-all"
                  >
                    <Smile className="w-4 h-4" />
                    <span>Submit Architecture Feedback</span>
                  </button>
                </div>
              ) : (
                /* Submission Interactive Form (True full-stack UX craftsmanship!) */
                <form onSubmit={handleSubmitReview} className="flex flex-col gap-4">
                  <div>
                    <h3 className="font-display font-bold text-lg text-white">Submit Case Studies</h3>
                    <p className="text-[10px] text-gray-500 font-mono">ALL SUBMISSIONS ARE DEPLOYED DIRECTLY TO SYSTEM STATE</p>
                  </div>

                  {formSubmitted ? (
                    <div className="py-12 flex flex-col items-center justify-center gap-3 text-center">
                      <CheckCircle2 className="w-12 h-12 text-emerald-400 animate-bounce" />
                      <h4 className="font-bold text-white text-md">Review Validated!</h4>
                      <p className="text-xs text-gray-400">Syncing transaction ledger state...</p>
                    </div>
                  ) : (
                    <>
                      {/* Name input */}
                      <div className="flex flex-col gap-1.5">
                        <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Full Name</label>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="e.g. Liam Patterson"
                          className="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-white/5 focus:border-cyan-400/50 text-white focus:outline-none font-sans"
                        />
                      </div>

                      {/* Role & Company input */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Engineering Role</label>
                          <input
                            type="text"
                            required
                            value={role}
                            onChange={(e) => setRole(e.target.value)}
                            placeholder="e.g. Lead Architect"
                            className="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-white/5 focus:border-cyan-400/50 text-white focus:outline-none"
                          />
                        </div>
                        <div className="flex flex-col gap-1.5">
                          <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Company</label>
                          <input
                            type="text"
                            required
                            value={company}
                            onChange={(e) => setCompany(e.target.value)}
                            placeholder="e.g. Apex Core Labs"
                            className="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-white/5 focus:border-cyan-400/50 text-white focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Content Review Area */}
                      <div className="flex flex-col gap-1.5">
                        <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Operational Feedback</label>
                        <textarea
                          required
                          rows={3}
                          value={content}
                          onChange={(e) => setContent(e.target.value)}
                          placeholder="What performance or visual latency changes did you observe?"
                          className="w-full px-3 py-2 text-sm rounded-lg bg-slate-950 border border-white/5 focus:border-cyan-400/50 text-white focus:outline-none font-sans resize-none"
                        />
                      </div>

                      {/* Rating selection */}
                      <div className="flex flex-col gap-1.5">
                        <label className="text-[10px] uppercase font-mono font-bold text-gray-400">Validation Rating</label>
                        <div className="flex items-center gap-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              type="button"
                              key={star}
                              onClick={() => setRating(star)}
                              className="p-1 rounded hover:bg-white/5 transition-all"
                            >
                              <Star
                                className={`w-5 h-5 ${star <= rating ? "text-amber-400 fill-amber-400" : "text-slate-600"}`}
                              />
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Submit and Cancel action rows */}
                      <div className="grid grid-cols-2 gap-3 mt-4">
                        <button
                          type="button"
                          onClick={() => setShowAddForm(false)}
                          className="py-2.5 rounded-xl border border-white/5 hover:border-white/10 text-xs font-bold text-gray-400 hover:text-white bg-white/5 transition-all"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="py-2.5 rounded-xl bg-gradient-to-r from-electric-purple to-neon-cyan text-xs font-bold text-white transition-all hover:scale-102"
                        >
                          Commit Block
                        </button>
                      </div>
                    </>
                  )}
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

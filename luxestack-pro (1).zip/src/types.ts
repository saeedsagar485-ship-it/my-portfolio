export interface Project {
  id: string;
  title: string;
  description: string;
  category: "AI Platform" | "FinTech" | "SaaS Core" | "DevTools";
  image: string;
  tags: string[];
  metrics: { label: string; value: string };
  longDescription?: string;
  demoUrl?: string;
  features?: string[];
}

export interface Feature {
  id: string;
  title: string;
  description: string;
  iconName: string; // Lucide icon name or FontAwesome class
  gradient: string; // e.g. "from-purple-500 to-indigo-500"
  badge?: string;
  interactiveType?: "toggle" | "chart" | "code" | "stats";
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  content: string;
  rating: number;
  date: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  gradient: string;
  isPopular: boolean;
  buttonText: string;
}

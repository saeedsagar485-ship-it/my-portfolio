import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Portfolio from "./components/Portfolio";
import PricingCalculator from "./components/PricingCalculator";
import Testimonials from "./components/Testimonials";
import Newsletter from "./components/Newsletter";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-[#0B0F19] text-gray-100 selection:bg-purple-500/30 selection:text-cyan-400 font-sans">
      {/* Background Micro Noise / Grain to add that ultra-premium visual depth */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.02] bg-[radial-gradient(#fff_1px,transparent_1px)] bg-[size:16px_16px] z-50" />

      {/* Main Single Page Layout Sections */}
      <Navbar />
      <main>
        <Hero />
        <Features />
        <Portfolio />
        <PricingCalculator />
        <Testimonials />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}
